# web-scraping

```bash
pip install -r requirements.txt

python ./news/crawl.py
```